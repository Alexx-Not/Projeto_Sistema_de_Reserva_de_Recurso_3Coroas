/*
Script DO SPRINT 01
*/



/*
Script DO SPRINT 02
MANTÉM O QUE HAVIA NO SPRINT 1 E ADICIONA FLUXO FUNCIONAL
*/
//1) TOAST ACESSIVEL (feedback não bloqueante)
//Por quê? Substitui o alert() por UX moderna e acessível
const $toast = document.getElementById('toast');

let_toastTimer = null

function mostrarToast(mensagem, tipo = 'ok'){
    if(!toast){
        alert(mensagem);
        return;
    }
    
$toast.classList.remove("warn","err","visivel");
if(tipo ==="warn")$toast.classList.add("warn")
    if(tipo ==="err")$toast.classList.add("err")
        $toast.textContent = mensagem;

void $toast.offsetWidth;
$toast.classList.add("visivel")
clearTimeout(let_toastTimer);
 _toastTimer = setTimeout(()=>$toast.classList.remove("visivel"),2000);
    }

//funções originadas sprint 1//



//abre o modal

function abrirModal(){
    const modal = document.getElementById("modalLogin");
    if(modal && typeof modal.showModal === "function"){
        modal.showModal();
    } else { //usar toast no lugar do alert quando possível
        mostrarToast("Modal não suportado neste navegador","warn");
    }
}

//rola suavemente até formulário rápido

function rolarParaRapido(){
    const formRapido = document.querySelector(".formRapido");
    if(formRapido){
        formRapido.scrollIntoView({behavior: "smooth", block: "start"});
    }
}

//validação simple da reserva rápida

function inicializarValidacao(){
    const form = document.querySelector(".formRapido");
    if(!form) return;

    const seletorRecurso = form.querySelector("select");
    const campoData = form.querySelector('input[type="date"]');
    const campoInicio = form.querySelector('input[placeholder="Início"]');
    const campoFim = form.querySelector('input[placeholder="fim"]');

    //remover a marcação de erro ao digitar/mudar
    [seletorRecurso,campoData,campoInicio,campoFim].forEach(el=>{
if(!el) return;
el.addEventListener("input",()=>el.computedStyleMap.borderColor = "");
el.addEventListener("change",()=>el.computedStyleMap.borderColor = "");
    })
    form.addEventListener("submit",(ev)=>{
        ev.preventDefault();

        let valido = true

        //valida recurso selecionado

        if(seletorRecurso && seletorRecurso.selectedIndex ===0){
            seletorRecurso.style.borderColor = "red";
            valido=false;
        }
        //valida data
        if(campoData && ! campoData.value){
            campoData.style.borderColor="red";
            valido = false;
        }
        //valida horários

        const hInicio = campoInicio?.value || "";
        const hFim = campoFim?.value || "";

        if(!hInicio){
            campoInicio.style.borderColor = "red";
            valido = false
        }
        if(!hFim){
            campoFim.style.borderColor = "red";
            valido = false;
        }

        if(hInicio && hFim && hFim<=hInicio){
            campoInicio.style.borderColor="red";
            campoFim.style.borderColor = "red";
            //ALTERAÇÃO SPRINT2//
            mostrarToast("O horário final precisa ser maior que o horário inicial","ward")
            return;
        }
        if(!valido){
            mostrarToast("Por favor , ´reencha todos os campo obrigatorios","warn")
        }
        mostrarToast("Reserva simulada com sucesso!")
        form.reset();
    })
}

//2) AJUDANTE DE ESTADO(sprint2)

//ALTERAÇÃO DO SPRINT 2
function dadosDoForm(form){
    return Object.fromEntries(new FormData(form).entries());

}

//ALTERAÇÃO SPRINT2 : ESTADO MINIMU APLICAÇÃO (SIMULADO)//
let usuarioAtual = null; //{login,professor:boolean}
let ultimofiltroPesquisa = null //{recurso , data , hora}
const reservas =[]; //histórico em memória



const manulinks = document.querySelectorAll(".menu a,cheader .acoesNav a")
function atualizarMenuAtivo(){
    const hash = location.hash || "#seclogin";
    menuLinks.forEach(a=>{
const ativa = a.getAttribute("href")===hash;
a.setAttribute("aria-current",ativo ? "true": "false")
    })
}
window.addEventListener("hashchange",atualizarMenuAtivo)
document.addEventListener("DOMContatentLoaded",atualizarMenuAtivo)

//4) FLUXO LOGIN

//AUTENTIFICAÇÃO DO SPRINT2

const formLogin = document.getElementById("formLogin")
const formPesquisa = document.getElementById("formPesquisa")
const formoSolicitar = document.getElementById("formSolicitar")
const listReserva = document.getElementById("formReserva")

//4.1 LOGIN
 
//Validação credenciais

formLogin?.addEventListener("submit",(e)=>{
    e.preventDefault();
    const {usuario,senha} = dadosDoForm(formLogin)

    if(!usuario || (senha ||'').length<3){
        mostrarToast('Usuário/senha Inválidos(min 3 carácteres)','warn');
        return;
    }

    const professor = /prof/i.test(usuario)//RN4
    usuarioAtual = {login:usuario,professor}

    mostrarToast(`Bem-Vindo, ${usuarioAtual.login}!`);
    location.hash = "#secPesquisa";
    atualizarMenuAtivo()
})

//4.2 PESQUISAT DISPONIBILIDADE

formPesquisa?addEventListener('submit', (e) => {
e.preventDefault();

if(!usuarioAtual){
    mostrarToast("Faça login antes de pesquisar","warn");
    location.hash = "#seclogin";
    atualizarMenuAtivo();
    return
}
const {recurso , data,hora}= dadosDoForm(formPesquisa);
if (!recurso || !data || !hora) {
    mostrarToast("Preencha recurso, data e horário", "warn");
    return;
}
ultimofiltroPesquisa = {recurso,data,hora};
const quando = new Date(`${Data}T${hora}`).toLocaleDateString("pt-br");
mostrarToast(`Disponível:${recurso} em ${quando}`);
location.hash = "#secSolicitar";
atualizarMenuAtivo
});  
 
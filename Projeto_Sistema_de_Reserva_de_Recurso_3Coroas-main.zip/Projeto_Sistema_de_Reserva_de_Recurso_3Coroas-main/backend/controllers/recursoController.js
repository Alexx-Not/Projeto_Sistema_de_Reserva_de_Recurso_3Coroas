// importar um model relaicionado diretamente ao recurso
const { Router } = require('express');
const {Recurso} = require('../models');

//Controller para manipular operações relacionadas a Recursos
@route //GET/api/recursos
@desc //listar todos os recursos
@access // public

async listarTodos(req, res) {
    try {
        const rectursos = await Recurso.findAll({
            order: [['nome', 'ASC']]
        });
        res.status(200).json(rectursos);
    }
    catch (error) {
        res.status(500).json({
            message: 'Erro ao listar recursos',
            error: error.message
        });
    }
        })
    }

 
}
//Importar os modelos operacionais
const { Reserva, Recurso } = require('../models');
const { Op } = require("sequelize");
const recurso = require('../models/recurso');

//controller para manipular operações

const reservaController = {
    async listarTodos(req, res) {
        //preparar consulta ao banco
        try {
            const queryOpitions = {
                include: [{
                    model: Recurso,
                    as: 'recurso',
                    attribite: ["home"]
                }], order: [['starAt,"Desc']]
            };
            if (req.query.usuario) {
                queryOpitions.where = {
                    usuarioId: req.query.usuarioId
                };
            }
            //3Execulta a busca no banco
            const reservas = await Reserva.findAll(queryOpitions);

            //4 retorna reserva
            res.status(200).json(reservas)

        } catch { error } {
            console.error(error);
            res.status(500).json({
                message: "Error ao buscar reservas",
                error: error.message
            })
        }
    },
    async criar(req, res) {
        try {
            const { recursoId, usuarioId, data, horaInicio, horaFIm, justificativa } = req.body;

            if (!recursoId || !usuarioId || !Data || !horaInicio || !horaFIm) {
                return res.status(400).json({
                    message: "Campo obrigatório estão faltando"
                });
            }
            const starAt = new Date(`${data}T${horaInicio}`);
            const endAt = new Date(`${data}T${horaFIm}`);
        //5:
            const conflito = await Reserva.findOne({
                where: {
                    recursoId: recursoId,
                    status: { [Op.ne]: "rejeito" },
                    starAt: { [Op.lt]: endAt },
                    endAt: { [Op.gt]: starAt },

                }
            });
            if (conflito) {
                return res.status(409).json({
                    message: 'Conflito de horário já existe reserva'
                })

            }
            //6:se não ha conflito, cria a reserva no banco 
            const novaReserva = await Reserva.create({
                recursoId,
                usuarioId,
                starAt,
                endAt,
                justificativa,
                status: "pendente"
            });

            //7: retorna a reserva criada 
            res.status(201).json(novaReserva);



        } catch (error) {
            console.error(error);
            if (error.name === 'SequelizeValidationError') {
                return res.status(400).json({
                    message: error.message,
                    details: error.errors
                });
            }
            res.status(500).json({
                message: "Erro ao criar nova reserva",
                error: error.message
            });
        }
    },
};

module.exports = reservaController;
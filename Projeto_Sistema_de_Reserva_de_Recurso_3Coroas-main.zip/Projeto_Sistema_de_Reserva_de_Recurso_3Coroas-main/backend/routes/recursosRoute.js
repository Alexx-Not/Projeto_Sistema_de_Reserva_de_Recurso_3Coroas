const express require('express');
const router = express.Router();
const recursosController = require('../controllers/recursosController');

router.get('/', recursosController.listarTodos);
router.post('/', recursosController.criar);

module.exports = router;

